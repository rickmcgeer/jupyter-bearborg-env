import {
   JupyterFrontEnd, JupyterFrontEndPlugin
} from '@jupyterlab/application';

import {
  ICommandPalette,  IFrame, MainAreaWidget // IMainMenu,
} from '@jupyterlab/apputils';

/* import {
  ILauncher
} from '@jupyterlab/launcher';
*/


// const TERMINAL_ICON_CLASS = 'jp-TerminalIcon';

/**
 * Initialization data for the bearborg_extension extension.
 */
const plugin: JupyterFrontEndPlugin<void> = {
  id: 'bearborg-extension',
  description: 'Display a BearBorg chat tab inside JupyterLab, following the standard Astronomy Picture of the Day example',
  autoStart: true,
  requires: [ICommandPalette],
  activate: (app: JupyterFrontEnd, palette: ICommandPalette) => {
    console.log('JupyterLab extension bearborg_extension is activated!');

    // Define a widget creator function,
    // then call it to make a new widget
    const newWidget = () => {
      // Create a blank content widget inside of a MainAreaWidget
      const content = new IFrame();
      const _iframe = content.node.querySelector('iframe')!;
      _iframe.src = 'https://bearborg.berkeley.edu'
      _iframe.removeAttribute('sandbox')
      const widget = new MainAreaWidget({ content });
      widget.id = 'bearborg';
      widget.title.label = 'BearBorg';
      widget.title.closable = true;
      return widget;
    }
    let widget = newWidget();

    // Add an application command
    const command: string = 'bearborg:open';
    app.commands.addCommand(command, {
      label: 'Open Bearborg',
      execute: () => {
        // Regenerate the widget if disposed
        if (widget.isDisposed) {
          widget = newWidget();
        }
        if (!widget.isAttached) {
          // Attach the widget to the main work area if it's not there
          app.shell.add(widget, 'main');
        }
        // Activate the widget
        app.shell.activateById(widget.id);
      }
    });

    // Add the command to the palette.
    palette.addItem({ command, category: 'Bearborg' });
  }
};

export default plugin;
